﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace C_
{
    class Program
    {
        static void Main(string[] args)
        {
            string dirPath = @"/home/prafulla/Downloads/Share-master/50SetsofSamplesofAcceleration_EDAQ";

            List<FileMap> map = new List<FileMap>();
            foreach (var subDir in Directory.GetDirectories(dirPath, "*.*", SearchOption.TopDirectoryOnly))
            {
                FileMap fileMap = new FileMap();
                map.Add(fileMap);
                var fileList_Chasi = new List<string>();
                var fileList_Vibx = new List<string>();
                var fileList_Viby = new List<string>();

                fileMap.Add(subDir, new List<List<string>> { fileList_Chasi, fileList_Vibx, fileList_Viby });

                foreach (var file in Directory.GetFiles(subDir, "*.*", SearchOption.TopDirectoryOnly))
                {
                    if (file.Contains("Chasi", StringComparison.InvariantCultureIgnoreCase))
                        fileList_Chasi.Add(file);
                    else if (file.Contains("Vibx", StringComparison.InvariantCultureIgnoreCase))
                        fileList_Vibx.Add(file);
                    else if (file.Contains("Viby", StringComparison.InvariantCultureIgnoreCase))
                        fileList_Viby.Add(file);




                }

                fileList_Chasi = fileList_Chasi.OrderBy(x => GetNum(x)).ToList();
                fileList_Vibx = fileList_Vibx.OrderBy(x => GetNum(x)).ToList();
                fileList_Viby = fileList_Viby.OrderBy(x => GetNum(x)).ToList();

                var minCount = new List<int>{fileList_Chasi.Count,
                fileList_Vibx.Count,fileList_Viby.Count}.Min();

                for (int i = 0; i < minCount; i++) //Number of files in each dir
                {

                    var f1 = File.OpenRead(fileList_Chasi[i]);
                    var f2 = File.OpenRead(fileList_Vibx[i]);
                    var f3 = File.OpenRead(fileList_Viby[i]);

                    var streamReader1 = new StreamReader(f1, Encoding.UTF8, true, 128);
                    var streamReader2 = new StreamReader(f2, Encoding.UTF8, true, 128);
                    var streamReader3 = new StreamReader(f3, Encoding.UTF8, true, 128);

                    StringBuilder buffer = new StringBuilder();
                    buffer.Append("Chasi,Vibx,Viby" + Environment.NewLine);
                    String line;
                    while ((line = streamReader1.ReadLine()) != null)
                    {
                        buffer.Append(line.TrimEnd());                      
                        buffer.Append(streamReader2.ReadLine().TrimEnd());                    
                        buffer.Append(streamReader3.ReadLine().TrimEnd());
                        buffer.Append(Environment.NewLine);
                    }

                    f1.Dispose();
                    f2.Dispose();
                    f3.Dispose();
                    streamReader1.Dispose();
                    streamReader2.Dispose();
                    streamReader3.Dispose();


                    var fileName = Path.Join(subDir, Path.GetFileNameWithoutExtension(subDir) + ".csv");
                    File.AppendAllText(fileName, buffer.ToString());

                }

            }

        }

        static int GetNum(string file)
        {

            var fname = Path.GetFileNameWithoutExtension(file);
            int lastIndex = fname.LastIndexOf('_');
            var numStr = fname.Substring(lastIndex + 1);

            int num = Int32.Parse(numStr);

            return num;
        }
    }
}
