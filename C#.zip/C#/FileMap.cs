
using System.Collections.Generic;

namespace C_
{
    class FileMap:Dictionary<string,List<List<string>>>
    {
        /// void Add(TKey key, TValue value);
        
    }
}